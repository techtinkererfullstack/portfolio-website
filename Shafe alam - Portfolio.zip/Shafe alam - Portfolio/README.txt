
Personal Portfolio (Generic Bootstrap template)

Pages included:
- index.html (Home)
- about.html (About)
- portfolio.html (Portfolio)
- services.html (Services)
- contact.html (Contact)

How to use:
1. Unzip and open index.html in a browser.
2. Replace images in the /images folder.
3. Edit text content in HTML files to match your details.
4. To enable the contact form, connect it to a backend or form service.
